% Limpieza de pantalla
clear all
close all
clc

% 1 TIEMPO %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tf = 40;              
ts = 0.04;           
t = 0:ts:tf;          
N = length(t);        

% 2 TRAYECTORIA DESEADA 
hxd = 5*t - 4*sin(t);
hyd = 5*t-4*cos(t)

% Derivadas
hxdp = 5 - 4*cos(t);
hydp = 5 + 4*sin(t);

% 3 CONDICIONES INICIALES
x1(1) = 0;
y1(1) = 0;
phi(1) = atan2(hyd(1), hxd(1));
hx(1) = x1(1);       
hy(1) = y1(1);       

% 4 CONTROL, BUCLE DE SIMULACIÓN
K = [18 0;
     0 13];

for k = 1:N
    hxe(k) = hxd(k) - hx(k);
    hye(k) = hyd(k) - hy(k);
    he = [hxe(k); hye(k)];
    Error(k) = norm(he);

    J = [cos(phi(k)) -sin(phi(k));
         sin(phi(k))  cos(phi(k))];

    hdp = [hxdp(k); hydp(k)];
    qpRef = pinv(J)*(hdp + K*he);
    v(k) = qpRef(1);
    w(k) = qpRef(2);

    phi(k+1) = phi(k) + w(k)*ts;

    xp1 = v(k)*cos(phi(k));
    yp1 = v(k)*sin(phi(k));
    x1(k+1) = x1(k) + ts*xp1;
    y1(k+1) = y1(k) + ts*yp1;

    hx(k+1) = x1(k+1);
    hy(k+1) = y1(k+1);
end

% 5 SIMULACIÓN VIRTUAL 3D
scene = figure;
set(scene, 'Color', 'white');
set(gca, 'FontWeight', 'bold');
sizeScreen = get(0,'ScreenSize');
set(scene, 'position', sizeScreen);
camlight('headlight');
axis equal
grid on
box on
xlabel('x(m)'); ylabel('y(m)'); zlabel('z(m)');
view([-0.1 90]);
axis tight;

scale = 2;
MobileRobot_5;
H1 = MobilePlot_4(x1(1), y1(1), phi(1), scale); hold on;
H2 = plot3(hx(1), hy(1), 0, 'r', 'lineWidth', 2);
H3 = plot3(hxd, hyd, zeros(1, N), 'g', 'lineWidth', 2);

step = 1;
for k = 1:step:N
    delete(H1);    
    delete(H2);
    H1 = MobilePlot_4(x1(k), y1(k), phi(k), scale);
    H2 = plot3(hx(1:k), hy(1:k), zeros(1,k), 'r', 'lineWidth', 2);
    pause(ts);
end

% 6 GRÁFICAS DE RESULTADOS
graph = figure;
set(graph, 'position', sizeScreen);
subplot(311)
plot(t, v, 'b', 'LineWidth', 2), grid on
xlabel('Tiempo [s]'), ylabel('m/s'), legend('Velocidad Lineal (v)');
subplot(312)
plot(t, w, 'g', 'LineWidth', 2), grid on
xlabel('Tiempo [s]'), ylabel('rad/s'), legend('Velocidad Angular (w)');
subplot(313)
plot(t, Error, 'r', 'LineWidth', 2), grid on
xlabel('Tiempo [s]'), ylabel('Error [m]'), legend('Error de posición');
